const BASEURL = "http://api.5mof.gg"

module.exports = {
    BASEURL,
  };